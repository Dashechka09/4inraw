import random

from PyQt5.QtWidgets import QGraphicsObject, QApplication
from PyQt5.QtCore import Qt, QRectF, QLineF, QMimeData, QPoint, pyqtSignal
from PyQt5.QtGui import QColor, QImage, QDrag, QPixmap

TOPLEFT_X = -200
TOPLEFT_Y = -200 # Где находится верхний левый край
BOARD_WIDTH = 400
BOARD_HEIGHT = 400
isGameOver = False
difficulty = 1


class Board(QGraphicsObject):
    """
    Возможности игровой доски
    """
    gameOverSignal = pyqtSignal(str)
    def __init__(self, computer, diff):
        super().__init__()
        global isGameOver, BOARD_HEIGHT, BOARD_WIDTH
        self.computer = computer  # Экземпляр класса компьютера
        self.gameOver = False
        isGameOver = self.gameOver
        self.result = ""
        self.ROW, self.COL = 8 * diff, 8 * diff  # Кол-во столбцов и строчек
        self.grid = [[0] * self.ROW for _ in range(self.COL)]  # Столбцы и строчки
        self.WIDTH, self.HEIGHT = 240*diff, 240*diff  # Ширина, высота
        BOARD_HEIGHT = self.HEIGHT
        BOARD_WIDTH = self.WIDTH
        self.turn = 1 #1 - player, 2 - computer
        self.CELLSIZE = 30  # Размер клетки
        self.loadImages()  # Подгрузка картинок

    def paint(self, painter, option, widget):
        """
        Нарисовать доску
        """
        if not self.gameOver:
            painter.setBrush(QColor(Qt.cyan))  # Кисть для рисования
            painter.drawRect(TOPLEFT_X, TOPLEFT_Y,
                             self.WIDTH, self.HEIGHT)  # Нарисовать прямоугольник

            # Рисование доски по столбцам и строчкам, а также рисование кружков противников
            for i in range(self.ROW):
                for j in range(self.COL):
                    if self.grid[i][j] == 1:
                        painter.drawImage(j * self.CELLSIZE + TOPLEFT_X,
                                          i * self.CELLSIZE + TOPLEFT_Y, REDDISK)
                    elif self.grid[i][j] == 2:
                        painter.drawImage(j * self.CELLSIZE + TOPLEFT_X,
                                          i * self.CELLSIZE + TOPLEFT_Y, BLACKDISK)

                    # Нарисовать сплошное изображение
                    painter.drawImage(j * self.CELLSIZE + TOPLEFT_X,
                                      i * self.CELLSIZE + TOPLEFT_Y, BOARDIMG)

    def updateGrid(self, row, col):
        """
        Обновление сетки
        """
        global isGameOver
        self.grid[row][col] = self.turn
        self.update()

        self.gameOver = self.isGameOver(self.turn)  # Флаг конца игры
        isGameOver = self.gameOver
        # Результат игры
        if isGameOver:
            self.gameOver = True

            if self.turn == 1:
                self.result = "Player"
            else:
                self.result = "Computer"
            print(f"The winner is {self.result}")
            self.gameOverSignal.emit(self.result)
            return

    def isGameOver(self, disk):
        """
        Проверка четырёх направлений на предмет конца игры
        """
        for i in range(self.ROW):
            for j in range(self.COL):
                if self.grid[i][j] == disk:
                    # Первое направление
                    if j in range(3) and i in range(self.ROW - 3):
                        if self.check4Direction(i, j, disk, dir4=[1, 2, 3]):
                            return True
                    # Второе направление
                    elif j in range(3, self.COL - 3) and i in range(self.ROW - 3):
                        if self.check4Direction(i, j, disk, dir4=[1, 2, 3, 4]):
                            return True
                    # Третье направление
                    elif j in range(self.COL - 4, self.COL) \
                            and i in range(self.ROW - 3):
                        if self.check4Direction(i, j, disk, dir4=[3, 4]):
                            return True
                    # Четвёртое направление
                    elif j in range(self.COL - 3) \
                            and i in range(self.ROW - 4, self.ROW):
                        if self.check4Direction(i, j, disk, dir4=[1]):
                            return True
        return False

    def check4Direction(self, i, j, disk, dir4=[]):
        """
        Проверка на 4 круга одинакового цвета в 4 направлениях
        """
        # Горизонтально 4 подряд
        if 1 in dir4 and self.grid[i][j + 1:j + 4] == [disk] * 3:
            print("Горизонтально 4 собрано")
            return True
        # Диагонально этот и другие 3 вниз подряд
        if 2 in dir4 and [col[j + k + 1] for k, col in enumerate(self.grid[i + 1:i + 4])] == [disk] * 3:
            print("Диагонально 4 собрано")
            return True
        # Вертикально 4 подряд
        if 3 in dir4 and [col[j] for col in self.grid[i + 1:i + 4]] == [disk] * 3:
            print("Вертикально 4 собрано")
            return True
        # Диагонально левее-вниз от этого 4 подряд
        if 4 in dir4 and [col[j - k - 1] for k, col in enumerate(self.grid[i + 1:i + 4])] == [disk] * 3:
            print("Диагонально 4 собрано")
            return True

    def boundingRect(self):
        """
        Возврат ограничивающего прямоугольника
        """
        return QRectF(TOPLEFT_X, TOPLEFT_Y,
                      self.WIDTH, self.HEIGHT)

    def loadImages(self):
        """
        Подгрузка картинок
        """
        global BOARDIMG, REDDISK, BLACKDISK, COMPWIN, PLAYERWIN
        BOARDIMG = QImage("images/4row_board.png").scaled(self.CELLSIZE,
                                                          self.CELLSIZE, Qt.KeepAspectRatio)
        REDDISK = QImage("images/4row_red.png").scaled(self.CELLSIZE,
                                                       self.CELLSIZE, Qt.KeepAspectRatio)
        BLACKDISK = QImage("images/4row_black.png").scaled(self.CELLSIZE,
                                                           self.CELLSIZE, Qt.KeepAspectRatio)


class DropArea(QGraphicsObject):
    """
    Пустое поле
    """
    global TOPLEFT_X, TOPLEFT_Y
    dropped = pyqtSignal(int, int)
    WIDTH = BOARD_WIDTH
    HEIGHT = 75
    TOPLEFT_x = TOPLEFT_X
    TOPLEFT_y = TOPLEFT_Y - HEIGHT

    def __init__(self, board):
        super().__init__()
        self.setAcceptDrops(True)
        self.board = board
        self.disk = 1

    def dropEvent(self, event):
        row, col = self.getCellToDrop(event.pos().x(), event.pos().y())
        self.dropped.emit(row, col)

    def getCellToDrop(self, mouseX, mouseY):
        currentCol = int((mouseX + 200) // self.board.CELLSIZE)
        return self.getEmptyRow(currentCol), currentCol

    def getEmptyRow(self, col):
        for i in range(self.board.ROW - 1, -1, -1):
            if self.board.grid[i][col] == 0:
                return i
        return -1

    def paint(self, painter, option, widget):
        painter.setBrush(QColor(Qt.darkGreen))
        painter.drawRect(DropArea.TOPLEFT_x, DropArea.TOPLEFT_y,
                         self.board.WIDTH, DropArea.HEIGHT)

    def boundingRect(self):
        return QRectF(DropArea.TOPLEFT_x, DropArea.TOPLEFT_y,
                      self.board.WIDTH, DropArea.HEIGHT)


class Computer:
    def __init__(self):
        pass

    def putDisk(self, grid):
        validCells = self.getAllValidCells(grid)
        num = random.randint(0, len(validCells) - 1)
        return validCells[num][0], validCells[num][1]

    def getAllValidCells(self, grid):
        validCells = []
        for j in range(len(grid)):
            for i in range(len(grid[j])-1, -1, -1):
                if grid[i][j] == 0:
                    validCells.append([i, j])  # [col, row]
                    break
        return validCells


class Player(QGraphicsObject):
    def __init__(self, CELLSIZE):
        super().__init__()
        self.circleSize = CELLSIZE

    def mousePressEvent(self, event):
        self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        global isGameOver
        if not isGameOver:
            if QLineF(event.screenPos(),
                      event.buttonDownScreenPos(Qt.LeftButton)).length() < \
                    QApplication.startDragDistance():
                return

            drag = QDrag(event.widget())
            mime = QMimeData()
            drag.setMimeData(mime)

            mime.setImageData(REDDISK)
            dragImg = REDDISK.scaled(self.circleSize, self.circleSize, Qt.KeepAspectRatio)
            drag.setPixmap(QPixmap.fromImage(dragImg))
            drag.setHotSpot(QPoint(dragImg.width() // 2, dragImg.height() // 2))

            drag.exec()
            self.setCursor(Qt.OpenHandCursor)

    def mouseReleasedEvent(self, event):
        self.setCursor(Qt.OpenHandCursor)

    def paint(self, painter, option, widget):
        """
        Пользователь перемещает свой кружок
        """
        painter.drawImage(-275, BOARD_HEIGHT-150, REDDISK)

    def boundingRect(self):
        return QRectF(-275, BOARD_HEIGHT-150, REDDISK.width(), REDDISK.height())
