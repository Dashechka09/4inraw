import sys
import time

from PyQt5.QtWidgets import QGraphicsScene, QGraphicsView, QMainWindow, QWidget, QVBoxLayout, QLabel, QPushButton, \
    QRadioButton, QButtonGroup, QGraphicsPixmapItem, QLayoutItem
from PyQt5.QtCore import QMetaObject, QCoreApplication, QRect, QTimer
from PyQt5.QtGui import QFont

from field import *

difficulty = 1
LABEL_STYLESHEET = '''font-weight: 500;
                        font-size: 64px;
                        color:#02C78C;'''
TEXT_STYLESHEET = '''   width:100%;
                        font-weight: 400;
                        font-size: 20px;
                        text-align: justify;
                        word-break: break-all;
                        color: #000000;
                    '''
GREEN_BTN_STYLESHEET = '''
                        background: #02C78C;
                        border-radius: 10px;
                        color: #FFFFFF;
                        padding: 10px;
                        font-weight: 500;
                        font-size: 20px;
'''
BLACK_BTN_STYLESHEET = '''
                        background: #5D5D5D;
                        color: #FFFFFF;
                        border-radius: 10px;
                        padding: 10px;
                        font-weight: 400;
                        font-size: 24px;
                        '''
WINDOW_TEMPLATE_STYLESHEET = '''
                background-image: url('images/bg.png');
                background-repeat: no-repeat;
                background-position: center;
                background-size:cover;
                width:100%;
                display:flex;
                align-items:center;
                '''

class MainWindow(QMainWindow):
    """
    Стартовое окно
    """

    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
    def setupUi(self, MainWindow):
        # Информация об окне

        MainWindow.setFixedWidth(800)
        MainWindow.setFixedHeight(600)
        MainWindow.setObjectName("MainWindow")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        # Лэйаут для центрирования кнопок
        self.buttonsLayout = QVBoxLayout()
        self.buttonsLayout.setAlignment(Qt.AlignHCenter)
        # Слой
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")


        # Текстовое поле
        self.WelcomeLabel = QLabel(self.centralwidget)

        # Шрифт для текстового поля
        font = QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)

        # Действие с текстовым полем
        self.WelcomeLabel.setFont(font)
        self.WelcomeLabel.setObjectName("WelcomeLabel")
        self.WelcomeLabel.setStyleSheet(LABEL_STYLESHEET)
        self.WelcomeLabel.setAlignment(Qt.AlignRight)
        self.verticalLayout.addWidget(self.WelcomeLabel)
        self.verticalLayout.addLayout(self.buttonsLayout)


        # Кнопка "Начать игру"
        self.StartGameButton = QPushButton(self.centralwidget)
        font = QFont()
        font.setPointSize(30)
        font.setBold(True)
        font.setWeight(75)
        self.StartGameButton.setFont(font)
        self.StartGameButton.setObjectName("StartGameButton")
        self.StartGameButton.setStyleSheet(BLACK_BTN_STYLESHEET)
        self.StartGameButton.setFixedWidth(250)
        self.buttonsLayout.addWidget(self.StartGameButton)
        self.StartGameButton.clicked.connect(self.RunGameWindow)

        # Кнопка правил
        self.RulesButton = QPushButton(self.centralwidget)
        font = QFont()
        font.setPointSize(30)
        font.setBold(True)
        font.setWeight(75)
        self.RulesButton.setFont(font)
        self.RulesButton.setObjectName("RulesButton")
        self.RulesButton.setStyleSheet(GREEN_BTN_STYLESHEET)
        self.RulesButton.setFixedWidth(250)
        self.buttonsLayout.addWidget(self.RulesButton)
        self.RulesButton.clicked.connect(self.RunRulesWindow)

        # Кнопка выбора сложности
        self.DifficultyButton = QPushButton(self.centralwidget)
        font = QFont()
        font.setPointSize(30)
        font.setBold(True)
        font.setWeight(75)
        self.DifficultyButton.setFont(font)
        self.DifficultyButton.setObjectName("DifficultyButton")
        self.DifficultyButton.setStyleSheet(GREEN_BTN_STYLESHEET)
        self.DifficultyButton.setFixedWidth(250)
        self.DifficultyButton.setFixedHeight(50)
        self.buttonsLayout.addWidget(self.DifficultyButton)
        MainWindow.setCentralWidget(self.centralwidget)
        self.DifficultyButton.clicked.connect(self.RunDifficultyWindow)

        self.retranslateUi(MainWindow)
        QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.WelcomeLabel.setText(_translate("MainWindow",
                                             "Четыре в ряд"))
        self.RulesButton.setText(_translate("MainWindow", "Правила игры"))
        self.StartGameButton.setText(_translate("MainWindow", "Начать игру"))
        self.DifficultyButton.setText(_translate("MainWindow", "Выбор сложности"))

    def RunGameWindow(self):
        """
        Запуск окна с игрой
        """
        self.GameWindow = GameWindow()
        self.GameWindow.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.GameWindow.showMaximized()

    def RunRulesWindow(self):
        """
        Запуск окна с правилами
        """
        self.RulesWindow = RulesWindow()
        self.RulesWindow.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.RulesWindow.show()

    def RunDifficultyWindow(self):
        """
        Окно выбора сложности
        """
        self.DifficultyWindow = DifficultyWindow()
        self.DifficultyWindow.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.DifficultyWindow.show()


class DifficultyWindow(QMainWindow):
    """
    Окно выбора сложности
    """

    def __init__(self):
        super(DifficultyWindow, self).__init__()
        self.setWindowTitle("Выбор сложности")
        self.setupUi(self)
    def setupUi(self, Form):
        global difficulty

        Form.setObjectName("DifficultyWindow")
        Form.setFixedWidth(800)
        Form.setFixedHeight(600)
        font = QFont()
        font.setPointSize(20)
        Form.setFont(font)
        self.label = QLabel(Form)
        self.label.setGeometry(QRect(14, 15, 771, 221))
        self.label.setObjectName("label")
        self.label.setAlignment(Qt.AlignRight)
        self.label.setStyleSheet(LABEL_STYLESHEET)
        self.widget = QWidget(Form)
        self.widget.setGeometry(QRect(10, 150, 781, 251))
        self.widget.setObjectName("widget")
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setSpacing(15)
        self.verticalLayout.setAlignment(Qt.AlignHCenter)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.radioButton = QRadioButton(self.widget)
        self.radioButton.setObjectName("radioButton")
        self.radioButton.setStyleSheet(TEXT_STYLESHEET)
        self.verticalLayout.addWidget(self.radioButton)
        self.radioButton_2 = QRadioButton(self.widget)
        self.radioButton_2.setStyleSheet(TEXT_STYLESHEET)
        self.radioButton_2.setObjectName("radioButton_2")
        self.verticalLayout.addWidget(self.radioButton_2)
        self.radioButton_3 = QRadioButton(self.widget)
        self.radioButton_3.setObjectName("radioButton_3")
        self.radioButton_3.setStyleSheet(TEXT_STYLESHEET)
        self.verticalLayout.addWidget(self.radioButton_3)

        match (difficulty):
            case 1:
                self.radioButton.setChecked(True)
            case 2:
                self.radioButton_2.setChecked(True)
            case 3:
                self.radioButton_3.setChecked(True)

        self.buttonGroup = QButtonGroup(Form)
        self.buttonGroup.setObjectName("buttonGroup")
        self.buttonGroup.addButton(self.radioButton)
        self.buttonGroup.addButton(self.radioButton_2)
        self.buttonGroup.addButton(self.radioButton_3)
        self.buttonGroup.buttonClicked.connect(self.ChangeDifficulty)

        self.retranslateUi(Form)
        QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "Выберите\nсложность"))
        self.radioButton.setText(_translate("Form", "Легко"))
        self.radioButton_2.setText(_translate("Form", "Средне"))
        self.radioButton_3.setText(_translate("Form", "Сложно"))

    def ChangeDifficulty(self, button):
        global difficulty
        text = button.text()
        if text == "Легко":
            difficulty = 1
        elif text == "Средне":
            difficulty = 2
        elif text == "Сложно":
            difficulty = 3


class RulesWindow(QMainWindow):
    """
    Окно с правилами
    """

    def __init__(self):
        super(RulesWindow, self).__init__()
        self.setWindowTitle("Правила игры")
        self.setupUi(self)

    def setupUi(self, Form):
        self.customCentralWidget = QWidget()
        self.centralLayout = QVBoxLayout()
        self.customCentralWidget.setLayout(self.centralLayout)
        self.centralLayout.setSpacing(10)
        self.setCentralWidget(self.customCentralWidget)

        Form.setObjectName("RulesWindow")
        Form.setFixedWidth(800)
        Form.setFixedHeight(600)
        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignRight)
        self.label.setStyleSheet(LABEL_STYLESHEET)
        self.label.setObjectName("label")
        self.centralLayout.addWidget(self.label)

        self.rulesText = QLabel()
        self.rulesText.setStyleSheet(TEXT_STYLESHEET)
        self.rulesText.setWordWrap(True)
        self.rulesText.setAlignment(Qt.AlignVCenter)
        self.centralLayout.addWidget(self.rulesText)

        self.retranslateUi(Form)
        QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "Правила"))
        self.rulesText.setText(_translate("Form", "<span>У каждого игрока есть набор цветных дисков.\nИгроки по очереди бросают свои диски в сетку, при этом диски падают в нижнюю часть сетки и складываются поверх любых дисков, которые уже были размещены. Игрок, который первым успешно соберет четыре своих диска подряд, побеждает в игре.</span>"))


class GameWindow(QMainWindow):
    """
    Окно с игрой
    """

    def __init__(self):
        super(GameWindow, self).__init__()
        self.setObjectName('GameWindow')
        self.setGeometry(100, 100, 600, 600)
        self.setWindowTitle("4 в ряд")
        self.customCentralWidget = QWidget(parent=self)
        self.setCentralWidget(self.customCentralWidget)
        self.centralLayout = QVBoxLayout()
        self.customCentralWidget.setLayout(self.centralLayout)
        self.restartButton = QPushButton(parent=self)
        self.restartButton.setText('Restart game')
        self.restartButton.setStyleSheet(GREEN_BTN_STYLESHEET)
        self.restartButton.clicked.connect(self.restartGame)
        self.restartButton.hide()
        self.initContent()

    def restartGame(self):
        """
        Можно, конечно, очищать имеющееся поле, но виджеты PyQT5 очень плохо поддаются перезаписи, тем более
        grapichs view различные - проще все переинициализировать
        """
        for i in reversed(range(self.centralLayout.count())):
            self.centralLayout.itemAt(i).widget().setParent(None)
        del self.view
        self.initContent()

    def initContent(self):
        self.view = GraphicsView()
        self.view.board.gameOverSignal.connect(self.restartButton.show)
        self.centralLayout.addWidget(self.view)
        self.centralLayout.addWidget(self.restartButton)
        self.restartButton.hide()



class GraphicsView(QGraphicsView):
    """
    Игровая доска
    """

    def __init__(self, parent=None):
        global difficulty
        QGraphicsView.__init__(self, parent=parent)
        self.timer = QTimer()
        self.computer = Computer()
        self.end = False
        self.board = Board(self.computer, difficulty)
        self.player = Player(self.board.CELLSIZE)
        self.dropArea = DropArea(self.board)
        self.board.gameOverSignal.connect(self.gameOver)
        self.dropArea.dropped.connect(self.playerMoves)

        scene = QGraphicsScene(self)
        scene.addItem(self.board)
        scene.addItem(self.dropArea)
        scene.addItem(self.player)
        self.setScene(scene)

    def letComputerMove(self):
        row, col = self.computer.putDisk(self.board.grid)
        self.board.updateGrid(row, col)
        self.board.turn = 1

    def gameOver(self, result):
        COMPWIN = QGraphicsPixmapItem(
            QPixmap.fromImage(QImage("images/YouLose.jpg")).scaled(self.width(), self.height(), Qt.KeepAspectRatio))
        PLAYERWIN = QGraphicsPixmapItem(
            QPixmap.fromImage(QImage("images/YouWin.jpg").scaled(self.width(), self.height(), Qt.KeepAspectRatio)))
        scene = QGraphicsScene(self)
        if result == "Player":
            scene.addItem(PLAYERWIN)
        else:
            scene.addItem(COMPWIN)
        self.setScene(scene)
        self.end = True

    def playerMoves(self, row, col):
        self.board.updateGrid(row, col)
        self.board.turn = 2
        self.letComputerMove()


def except_hook(cls, exception, traceback):
    """
    Узнать информацию об ошибке
    """
    sys.__excepthook__(cls, exception, traceback)


def main():
    """
    Основная функция, открывает стартовое окно игры
    """

    app = QApplication(sys.argv)
    stylesheet = ''' #MainWindow, #DifficultyWindow, #RulesWindow {
                background-image: url('images/bg.png');
                background-repeat: no-repeat;
                background-position: center;
                background-size:cover;
                width:100%;
                display:flex;
                align-items:center;
                }
        '''
    StartGameWindow = MainWindow()
    app.setStyleSheet(stylesheet)
    StartGameWindow.show()
    sys.excepthook = except_hook
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
